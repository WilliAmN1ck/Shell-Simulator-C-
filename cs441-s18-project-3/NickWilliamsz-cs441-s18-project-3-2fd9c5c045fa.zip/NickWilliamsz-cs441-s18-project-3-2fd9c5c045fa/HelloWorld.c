//
//  HelloWorld.c
//  
//
//  Created by Nick W on 2/27/18.
//

#include <stdio.h>

int main(int argc, char ** argv) {
    printf("Hello, World!\n");
    return 0;
}
